package dao;

public class GalleryDAO {

}
